import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Producto } from 'src/app/_model/producto';
import { ProductoService } from 'src/app/_service/producto.service';
import { ProductoDialogoComponent } from './producto-dialogo/producto-dialogo.Component';
import { switchMap } from 'rxjs/operators';

@Component({
  selector: 'app-producto',
  templateUrl: './producto.component.html',
  styleUrls: ['./producto.component.css']
})
export class ProductoComponent implements OnInit {

  displayedColumns = ['idProducto', 'nombres', 'marca', 'acciones'];
  dataSource: MatTableDataSource<Producto>;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort : MatSort;

  constructor(
    private productoService : ProductoService,
    private dialog: MatDialog,
    private snackBar: MatSnackBar) { }

    ngOnInit(): void {
      this.productoService.getProductoCambio().subscribe(data => {
        this.crearTabla(data);
      });

      this.productoService.getMensajeCambio().subscribe(data => {
        this.snackBar.open(data, 'AVISO', { duration: 2000 });
      })

      this.productoService.listar().subscribe(data => {
        this.crearTabla(data);
      })
    }

    filtrar(valor: string) {
      this.dataSource.filter = valor.trim().toLowerCase();
    }

    abrirDialogo(producto?: Producto) {
      this.dialog.open(ProductoDialogoComponent, {
        data: producto,
        width: '250px'
      });
    }

    eliminar(producto: Producto) {
      this.productoService.eliminar(producto.idProducto).pipe(switchMap(() => {
        return this.productoService.listar();
      })).subscribe(data => {
        this.productoService.setProductoCambio(data);
        this.productoService.setMensajeCambio('Se eliminó');
      });
    }

    crearTabla(data: Producto[]) {
      this.dataSource = new MatTableDataSource(data);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    }

}
