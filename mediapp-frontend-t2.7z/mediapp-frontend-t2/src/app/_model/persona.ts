export class Persona {
  idPersona: number;
  nombres: string;
  apellidos: string;
}
