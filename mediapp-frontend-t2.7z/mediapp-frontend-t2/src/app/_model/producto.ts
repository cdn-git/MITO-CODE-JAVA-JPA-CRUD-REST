export class Producto {
  idProducto: number;
  nombre: string;
  marca: string;
}
